<script>
    export default {
        name: 'app',
        data() {
            return {
                title: 'Sign-in to your account',
                buttonText: 'Sign-in'
            }
        },
        methods: {
            signupTitle() {
                this.title = 'Signup for a new account!';
                this.buttonText = 'Signup';
            }
        },
        render(h) {
            return (
                <div>
                    <div id="login-dialog">
                        <div id="login-title">{this.title}</div>
                            <div class="input-holder">
                                <input type="text" placeholder="E-Mail" />
                            </div>
                            <div class="input-holder">
                                <input type="password" placeholder="Password" />
                            </div>
                            <div class="input-holder">
                                <a href="#" id="signinBtn">{this.buttonText}</a>
                                <div class="text-links">
                                    <a href="#" id="signupBtn" onClick={this.signupTitle}>Signup for a free account!</a>
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
    }
</script>

<style>
    @import '/static/style.css'; 
</style>