import Vue from 'vue'
import Firebase from 'firebase'
import VueFire from 'vuefire'

Vue.use(VueFire);

const config = {
  apiKey: "--api-key--",
  authDomain: "--auth-domain--",
  databaseURL: "--database-url--",
  projectId: "--project-id--",
  storageBucket: "--storage-bucket--",
  messagingSenderId: "--messaging-sender-id--"
}

const FireBaseApp = Firebase.initializeApp(config);
const FireDB = FireBaseApp.database();
const firebase = function() {
  return {
    contacts: FireDB.ref('contacts')
  }
}
const isConnected = FireDB.ref('.info/connected');

export {
  firebase,
  isConnected
}
