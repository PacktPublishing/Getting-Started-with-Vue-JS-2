<template>
  <div v-if="contact">
    <router-link to="/" id="cancelBtn" />
    <a href="#" id="deleteBtn" @click.prevent="showDeleteDialog = true" v-if="isOnline"/>
    <div class="contact-detail-pane">
      <span class="detail-name">{{contact.name}}</span>
      <span class="detail-phone">{{contact.phone}}</span>
      <span class="detail-email">{{contact.email}}</span>
      <span class="detail-address">{{contact.address}}</span>
      <div class="social-ids">
        <div class="social-id">
          <span :class="['icon', 'fbico', contact.fbHandle ? '' : 'icodisabled']" />
          <span class="social-id-value">{{contact.fbHandle}}</span>
        </div>
        <div class="social-id">
          <span :class="['icon', 'twico', contact.twitterHandle ? '' : 'icodisabled']" />
          <span class="social-id-value">{{contact.twitterHandle}}</span>
        </div>
        <div class="social-id">
          <span :class="['icon', 'instaico', contact.instaHandle ? '' : 'icodisabled']" />
          <span class="social-id-value">{{contact.instaHandle}}</span>
        </div>
        <div class="social-id">
          <span :class="['icon', 'linkedinico', contact.linkedinHandle ? '' : 'icodisabled']" />
          <span class="social-id-value">{{contact.linkedinHandle}}</span>
        </div>
      </div>
    </div>
    <user-response
      v-if="showDeleteDialog"
      @agree="deleteContact(id)"
      @disagree="showDeleteDialog = false">
      Do you wish to delete this contact?
    </user-response>
  </div>
</template>

<script>
  import {firebase} from '@/db'
  import UserResponse from './UserResponse'
  export default {
    name: 'contact-detail',
    props: ['isOnline', 'id'],
    components: {
      UserResponse
    },
    data() {
      return {
        contacts: [],
        contact: {},
        showDeleteDialog: false
      }
    },
    firebase,
    created() {
      this.getData();
    },
    watch: {
      contacts: 'getData',
      '$route': 'getData'
    },
    methods: {
      getData() {
        let contact = this.contacts.filter(item => {
          return item['.key'] === this.id;
        });

        if(contact.length > 0) {
          this.contact = contact[0];
        } else {
          this.$router.push('/');
        }
      },
      deleteContact(key) {
        if(this.isOnline) {
          this.$firebaseRefs.contacts.child(key).remove();
          this.showDeleteDialog = false;
          this.$router.push('/');
        }
      }
    }
  }
</script>
