<template>
    <div v-if="isOnline">
        <div id="login-cover" />
        <div id="login-container">
            <div id="login-title">Login</div>
            <div class="field-holder"><input type="text" v-model="email" placeholder="E-mail"></div>
            <div class="field-holder"><input type="password" v-model="password" placeholder="Password"></div>
            <div class="field-holder">
                <a href="#" id="login-btn" @click.prevent="doLogin">Login</a>
                <a href="#" id="signup-btn" @click.prevent="signUp">Signup</a>
                <a href="#" id="reset-password-btn" v-if="email !== ''" @click.prevent="showResetDialog = true">Reset Password</a>
            </div>
            <div class="field-holder"><span :class="['notification', {'notification-show' : showMessage}]">{{messageTxt}}</span></div>
        </div>
        <user-response 
            v-if="showResetDialog"
            @agree="resetPassword"
            @disagree="showResetDialog = false">
            Do you wish to reset your password?
        </user-response>
    </div>
</template>

<script>
    import {Auth} from '@/firebase'
    import UserResponse from './UserResponse'
    export default {
        name: 'auth-ui',
        props: ['isOnline'],
        components: {
            UserResponse
        },
        data() {
            return {
                email: '',
                password: '',
                showResetDialog: false,
                showMessage: false,
                messageTxt: ''
            }
        },
        methods: {
            clearOut() {
                this.email = '';
                this.password = '';
            },
            doLogin() {
                Auth.signInWithEmailAndPassword(this.email, this.password)
                    .then(() => {
                        this.clearOut();
                        this.$router.push('/');
                    })
                    .catch(error => this.errorMsg(error));
            },
            signUp() {
                if(this.email && this.password && this.isOnline) {
                    Auth.createUserWithEmailAndPassword(this.email, this.password)
                        .then(() => {
                            this.clearOut();
                            this.$router.push('/');
                        })
                        .catch(error => this.errorMsg(error));
                }
            },
            resetPassword() {
                Auth.sendPasswordResetEmail(this.email)
                    .then(() => {
                        this.showResetDialog = false;
                        this.showMsg('A password reset mail has been sent to you!');
                    })
                    .catch(error => {
                        this.showResetDialog = false;
                        this.errorMsg(error);
                    });
            },
            showMsg(txt = 'An unknown error has occurred.', clear = true) {
                this.messageTxt = txt;
                this.showMessage = true;
                setTimeout(() => {
                    this.showMessage = false;
                }, 3000);

                if(clear) {
                    this.clearOut();
                }
            },
            errorMsg(error) {
                const errorDict = [{
                    code: 'auth/invalid-email',
                    message: 'The email address provided was incorrect!'
                }, {
                    code: 'auth/wrong-password',
                    message: 'Incorrect password!'
                }, {
                    code: 'auth/email-already-in-use',
                    message: 'An account exists for this email address!'
                }];

                let msgTxt = errorDict.filter(item => item.code === error.code);
                this.showMsg(msgTxt.length > 0 ? msgTxt[0]['message'] : error.message);
            }
        }
    }
</script>

<style scoped>
#login-cover {
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.3);
}

#login-container {
  position: absolute;
  border: 1px solid rgba(255, 0, 0, 0.2);
  width: 450px;
  height: 450px;
  left: 0px;
  right: 0px;
  top: 20px;
  bottom: 0px;
  margin: auto;
  background-color: rgb(100%, 99.9%, 99.9%);
  z-index: 10;
}

#login-title {
    position: relative;
    top: 0px;
    width: 450px;
    font-size: 40px;
    line-height: 80px;
    border-bottom: 1px dashed red;
    text-align: center;
    text-shadow: 0px 1px 1px rgba(0,0,0,0.5);
    font-weight: bold;
}

.field-holder {
    position: relative;
    box-sizing: border-box;
    padding: 20px;
}

input {
    padding: 20px;
    width: 365px;
    font-size: 20px;
    border: none;
    border-bottom: 2px solid red;
    outline: none;
    margin-bottom: 5px;
}

#login-btn {
    position:relative;
    font-size: 25px;
    text-decoration: none;
    background-color: rgb(90.5%, 28.6%, 28.6%);
    padding: 12px;
    color: rgb(255, 255, 255);
    font-weight: bold;
}

#signup-btn {
    position:relative;
    font-size: 25px;
    text-decoration: none;
    background-color: rgb(38.6%, 83.1%, 38.6%);
    padding: 12px;
    color: rgb(255, 255, 255);
    font-weight: bold;
}

#reset-password-btn {
    position: absolute;
    top: 25px;
    color: rgb(0, 0, 0);
    font-size: 16px;
    right: 25px;
    transition: color 300ms;
}

#reset-password-btn:hover {
    color: rgb(255, 0, 0);
}

span.notification {
    background-color: red;
    padding: 5px;
    color: rgb(255, 255, 255);
    font-weight: bold;
    line-height: 32px;
    opacity: 0;
    transition: opacity 200ms;
}

span.notification-show {
    opacity: 1;
}
</style>