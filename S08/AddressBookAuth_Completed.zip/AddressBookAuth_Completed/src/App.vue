<template>
  <div id="addressbook-app">
    <h2 id="title">Address Book</h2>
    <a href="#" id="logoutBtn" v-if="uid" @click.prevent="signOutNow" />
    <div class="offline-note" v-if="!isOnline">{{statusMessage}}</div>
    <router-view :isOnline="isOnline" :uid="uid" />
  </div>
</template>

<script>
  import {isConnected, Auth} from './firebase'
  export default {
    name: 'app',
    data() {
      return {
        isOnline: false,
        statusMessage: 'Loading....',
        uid: null
      }
    },
    created() {
      isConnected.on('value', status => {
        if(status.val()) {
          this.isOnline = true;
          this.statusMessage = "We're offline at the moment!";
        } else {
          this.isOnline = false;
        }
      });

      Auth.onAuthStateChanged(user => {
        if(user) {
          this.uid = user.uid;
        } else {
          this.uid = null;
        }
      });
    },
    methods: {
      signOutNow() {
        Auth.signOut();
      }
    }
  }
</script>

<style>
  @import "/static/css/address-book.css";
</style>
