import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import AddContact from '@/components/AddContact'
import ContactDetail from '@/components/ContactDetail'
import AuthUI from '@/components/AuthUI'
import {Auth} from '@/firebase'

Vue.use(Router);

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home,
      meta: {
        authRequired: true
      }
    },
    {
      path: '/add',
      name: 'AddContact',
      component: AddContact,
      meta: {
        authRequired: true
      }
    },
    {
      path: '/detail/:id',
      name: 'ContactDetail',
      component: ContactDetail,
      props: true,
      meta: {
        authRequired: true
      }
    },
    {
      path: '/login',
      name: 'Login',
      component: AuthUI
    }
  ]
});

router.beforeEach((to, from, next) => {
  if(to.matched.some(item => item.meta.authRequired)) {
    // Verify if logged in before routing
    Auth.onAuthStateChanged(function(user) {
      if(user) {
        // Logged in
        next();
      } else {
        // Redirect to Login route
        next('/login');
      }
    });
  } else {
    next();
  }
});

export default router;
