'use strict';
import './styles/style.scss'
import palindrome from './js/palindrome'
import {debounce} from 'lodash'

const inputBox = document.querySelector("#inputBox");
const resultDisplay = document.querySelector("#result");

inputBox.addEventListener('keyup', debounce(function(evt) {
  if(evt.target.value) {
    // let the user know if the word was a palindrome or not
    resultDisplay.innerText = palindrome(evt.target.value) ? "Bingo! It's a palindrome!" : "Nope, its not...";
  } else {
    resultDisplay.innerText = "...";
  }
  // doSomethingCool();
}, 400));

function doSomethingCool() {
  console.log("This function does something really cool!");
  return true;
}
