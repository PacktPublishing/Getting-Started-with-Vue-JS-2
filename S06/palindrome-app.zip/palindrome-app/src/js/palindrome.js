'use strict';

export default function palindrome(str) {
  const strProc = str.trim().toLowerCase().replace(/(?!\w)./g,'');
  const reverseStr = strProc.split('').reverse().join('');
  return strProc === reverseStr;
}
