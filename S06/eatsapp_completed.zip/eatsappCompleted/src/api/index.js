'use strict';
import axios from 'axios';
const apiUri = process.env.API_URI;

export default function() {
  return axios.get(apiUri);
  // Returns a Promise
}
