<template>
  <div class="rating-meter">
    <img class="rating-star" :src="getIcon"
      v-for="x in rating" />
  </div>
</template>

<script>
  export default {
    name: 'rating-meter',
    props: {
      rating: {
        type: Number,
        required: true,
        default: 1,
        validator: function(value) {
          return value > 0 && value < 6;
        }
      }
    },
    computed: {
      getIcon: function() {
        if(this.rating > 4) {
          return 'static/goldStar.svg';
        } else if (this.rating > 2 && this.rating <= 4) {
          return 'static/silverStar.svg';
        } else {
          return 'static/bronzeStar.svg';
        }
      }
    }
  }
</script>

<style>
  .rating-meter {
    position: relative;
  }
</style>
