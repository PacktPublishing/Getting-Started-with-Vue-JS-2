<template>
  <div class="list-item-photo-inner" :style="bgImage" />
</template>

<script>
  export default {
    name: 'list-item-photo',
    props: ['source'],
    computed: {
      bgImage: function() {
        return {
          'background-image': `url(${this.source})`
        }
      }
    }
  }
</script>

<style>
  .list-item-photo-inner {
    width: 68px;
    height: 68px;
    border-radius: 34px;
  }
</style>
