<template>
  <div class="info-card">
    <div class="head-pic">
      <img :src="eatery.photos.head"/>
    </div>
    <div class="info-name">{{eatery.name}}</div>
    <div class="info-type">{{eatery.type.join(' | ')}}</div>
    <div class="info-description">{{eatery.description}}</div>
    <rating-meter :rating="eatery.rating" class="info-rating" />
  </div>
</template>

<script>
  import RatingMeter from './RatingMeter'
  export default {
    name: 'info-card',
    props: ['eatery'],
    components: {
      RatingMeter
    }
  }
</script>

<style lang="sass">
  .info-card
    position: relative
    height: 280px
    width: 700px

  .head-pic
    position: absolute
    width: 160px
    height: 278px
    background-color: rgb(121, 121, 121)

  .info
    position: absolute
    left: 180px
    font-family: 'Raleway', sans-serif
    font-weight: 600

  .info-name
    @extend .info
    top: 20px
    font-size: 30px
    color: rgb(174, 0, 21)

  .info-type
    @extend .info
    top: 60px
    font-size: 15px

  .info-description
    @extend .info
    top: 90px
    font-size: 13px

  div.info-rating
    @extend .info
    position: absolute
    bottom: 12px
</style>
