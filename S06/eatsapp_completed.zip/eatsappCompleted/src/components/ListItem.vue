<template>
  <div class="list-item"
    @click.prevent="$emit('getDetails')">
    <list-item-photo class="list-item-photo" :source="listData.photo" />
    <list-item-text class="list-item-text" :name="listData.name" :type="listData.type" />
    <rating-meter class="list-item-rating" :rating="listData.rating" />
  </div>
</template>

<script>
  import ListItemPhoto from './ListItemPhoto'
  import ListItemText from './ListItemText'
  import RatingMeter from './RatingMeter'

  export default {
    name: 'list-item',
    props: ['listData'],
    components: {
      ListItemPhoto,
      ListItemText,
      RatingMeter
    }
  }
</script>

<style>
  .list-item {
    position: relative;
    height: 80px;
    background-color: rgb(241, 241, 241);
    margin-bottom: 2px;
    cursor: pointer;
  }

  .list-item-photo {
    position: absolute;
    top: 6px;
    left: 14px;
  }

  .list-item-text {
    position:absolute;
    top: 15px;
    left: 107px;
  }

  .list-item-rating {
    position: absolute;
    left: 550px;
    top: 30px;
  }
</style>
