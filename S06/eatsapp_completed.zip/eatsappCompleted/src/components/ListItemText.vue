<template>
  <div>
    <p class="list-item-text-name">{{name}}</p>
    <p class="list-item-text-type">{{type.join(" | ")}}</p>
  </div>
</template>

<script>
  export default {
    name: 'list-item-text',
    props: ['name', 'type']
  }
</script>

<style>
  .list-item-text-name {
    position: relative;
    font-family: 'Raleway', sans-serif;
    font-size: 25px;
    margin: 0;
    padding: 0;
    font-weight: 600;
  }

  .list-item-text-type {
    position: relative;
    margin: 0;
    font-family: 'Raleway', sans-serif;
    font-size: 15px;
    color: rgb(139, 87, 42);
    font-weight: 600;
    margin-top: 5px;
  }
</style>
