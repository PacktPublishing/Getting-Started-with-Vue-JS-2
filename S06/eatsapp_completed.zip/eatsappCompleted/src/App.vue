<template>
  <div class="app-container">
    <div class="list-container">
      <list-item
        v-for="item in db"
        :key="item.code"
        :listData="listItemData(item)"
        @getDetails="getDetails(item.code)" />
    </div>
    <div class="info-card-container">
      <info-card :eatery="selectedEatery" />
    </div>
  </div>
</template>

<script>
  import api from './api';
  import ListItem from './components/ListItem';
  import InfoCard from './components/InfoCard';

  export default {
    name: 'eatsapp',
    components: {
      ListItem,
      InfoCard
    },
    data() {
      return {
        db: [],
        selectedEatery: null
      }
    },
    created() {
      api()
        .then(response => {
          this.db = response.data;
          this.getDetails(response.data[0].code);
        });
    },
    methods: {
      listItemData(item) {
        return {
          name: item.name,
          type: item.type,
          photo: item.photos['thumb'],
          rating: item.rating
        }
      },
      getDetails(code) {
        this.selectedEatery = this.db.filter(item => item.code === code)[0];
      }
    }
  }
</script>

<style>
  @import url('https://fonts.googleapis.com/css?family=Raleway:300');

  body {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  .app-container {
    position:absolute;
    width: 700px;
    height: 611px;
    border: 1px solid rgb(151, 151, 151);
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
  }

  .list-container {
    position: relative;
    height: 330px;
    border-bottom: 2px solid rgb(255, 0, 0);
    overflow-x: hidden;
    overflow-y: auto;
  }

  .info-card-container {
    position: relative;
    height: 280px;
  }
</style>
