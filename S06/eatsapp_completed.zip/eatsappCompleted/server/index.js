'use strict';
const http = require('http');
const path = require('path');
const dataset = [
  {
    "code": "DAC01",
    "name": "Dev's American Cafe",
    "type": [
      "Cafe",
      "American",
      "Quick Eats"
    ],
    "photos": {
      "thumb": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282465/devsAmericanCafe_small_llemch.jpg",
      "head": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282464/devsAmericanCafe_large_w0kucy.jpg"
    },
    "description": "A quirky open air cafeteria situated inside the premises of a school that serves amazing American fare. Try their burgers.",
    "rating": 5
  },
  {
    "code": "RD02A",
    "name": "Rustic Door",
    "type": [
      "Continental",
      "All Day Breakfast",
      "Quick Eats"
    ],
    "photos": {
      "thumb": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282460/rusticDoor_small_rdhnz3.jpg",
      "head": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282464/rusticDoor_large_zwjzol.jpg"
    },
    "description": "An eclectic ensemble of continental fare, all day breakfast and quick eats from around the world.",
    "rating": 1
  },
  {
    "code": "GDS01IC",
    "name": "Get Desserted",
    "type": [
      "Ice Cream",
      "Desserts"
    ],
    "photos": {
      "thumb": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282460/getDesserted_small_osqfkg.jpg",
      "head": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282464/getDesserted_large_jgsyxp.jpg"
    },
    "description": "There's always room for desserts. Get Desserted is a quick service restaurant that serves freshly made nitrogen churned ice cream, belgian waffles and sorbets.",
    "rating": 2
  },
  {
    "code": "CRSPZ03",
    "name": "Crusto's Pizza",
    "type": [
      "Pizzeria"
    ],
    "photos": {
      "thumb": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282460/crustos_small_gubvgd.jpg",
      "head": "http://res.cloudinary.com/dikniqpsy/image/upload/v1492282461/crustos_large_ddpoqz.jpg"
    },
    "description": "Crusto's brings to the city, hand tossed, flatbread pizzas baked in a wood fired oven, right infront of your very eyes. Also on the menu are Pizza Rolls, coolers and more. Try their Salmon Pizza.",
    "rating": 4
  }
];

// Server instance
http.createServer(function(req, res) {
  if(req["url"] === '/') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify(dataset, null, 2));
  } else {
    res.writeHead(200);
    res.end("To access data, visit the / endpoint");
  }

}).listen(3000, () => console.log("Getting Started with Vue.js (@sachinbee)| EatsApp API Server on Port 3000"));
